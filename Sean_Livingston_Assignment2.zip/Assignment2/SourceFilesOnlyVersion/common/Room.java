package common;

public class Room {

    private int qualityLevel;
    private int beds;
    private int roomNumber;
    private boolean smokingStatus;
    private boolean availability;
    private double price;
    private String description;
    private int reservationNumber;
    
}
