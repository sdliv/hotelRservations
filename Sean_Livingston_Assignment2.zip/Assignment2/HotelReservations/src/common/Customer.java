package common;

public class Customer extends Person {

    public Customer(String firstName, String lastName) {
        super(firstName, lastName);
    }
}
