package common;

public class Employee extends Person {
    public Employee(String firstName, String lastName) {
        super(firstName, lastName);
    }
}
