package common;

public class Administrator extends Person {
    public Administrator(String firstName, String lastName) {
        super(firstName, lastName);
    }
}
