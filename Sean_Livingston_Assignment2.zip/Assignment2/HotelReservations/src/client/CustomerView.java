package client;

import common.Customer;
import hotel.ReservationImpl;

public class CustomerView {
    public void printReservationDetails(Customer customer, ReservationImpl reservation) {
        Customer customer1 = new Customer("Sean", "Livingston");
    }
}
